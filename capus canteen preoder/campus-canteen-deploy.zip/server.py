# ==============================================================================
# Campus Canteen – Food Pre-Order System (MongoDB Backend)
# File: server.py
# Description: Flask REST API + MongoDB Database Server
# ==============================================================================

import os
import sys
import json
import uuid
import hashlib
from datetime import datetime

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder=".")
CORS(app)

# ------------------------------------------------------------------------------
# 1. DATABASE LAYER: PyMongo with Auto-Fallback Persistent Document Store
# ------------------------------------------------------------------------------
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/campus_canteen")
DB_NAME = "campus_canteen"
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DATA_FILE = os.path.join(DATA_DIR, "canteen_db.json")

use_real_mongo = False
mongo_client = None
db = None

try:
    from pymongo import MongoClient
    mongo_client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=1500)
    # Ping database to check if server is reachable
    mongo_client.admin.command('ping')
    db = mongo_client[DB_NAME]
    use_real_mongo = True
    print(f"[OK] Successfully connected to local MongoDB server at: {MONGO_URI}")
except Exception as e:
    print(f"[INFO] Standalone MongoDB server (mongod) not running on port 27017.")
    print("[INFO] Initializing Local Persistent MongoDB Document Store (data/canteen_db.json)...")

# Local Persistent JSON Document Store (when standalone mongod is not running)
class LocalMongoCollection:
    def __init__(self, name):
        self.name = name

    def _read_all(self):
        if not os.path.exists(DATA_FILE):
            os.makedirs(DATA_DIR, exist_ok=True)
            initial_data = {"users": [], "foodItems": [], "orders": []}
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(initial_data, f, indent=2)
            return initial_data.get(self.name, [])
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get(self.name, [])
        except Exception:
            return []

    def _write_all(self, items):
        os.makedirs(DATA_DIR, exist_ok=True)
        data = {}
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}
        data[self.name] = items
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def find(self, query=None):
        items = self._read_all()
        if not query:
            return items
        results = []
        for item in items:
            match = True
            for k, v in query.items():
                if item.get(k) != v:
                    match = False
                    break
            if match:
                results.append(item)
        return results

    def find_one(self, query):
        items = self.find(query)
        return items[0] if items else None

    def insert_one(self, document):
        items = self._read_all()
        if "_id" not in document:
            document["_id"] = str(uuid.uuid4())
        items.append(document)
        self._write_all(items)
        return document

    def update_one(self, query, update):
        items = self._read_all()
        updated = False
        update_fields = update.get("$set", update)
        for item in items:
            match = True
            for k, v in query.items():
                if item.get(k) != v:
                    match = False
                    break
            if match:
                for uk, uv in update_fields.items():
                    item[uk] = uv
                updated = True
                break
        if updated:
            self._write_all(items)
        return updated

    def delete_one(self, query):
        items = self._read_all()
        new_items = []
        deleted = False
        for item in items:
            match = True
            for k, v in query.items():
                if item.get(k) != v:
                    match = False
                    break
            if not match:
                new_items.append(item)
            else:
                deleted = True
        if deleted:
            self._write_all(new_items)
        return deleted

    def count_documents(self, query=None):
        return len(self.find(query))


class LocalMongoDB:
    def __init__(self):
        self.users = LocalMongoCollection("users")
        self.foodItems = LocalMongoCollection("foodItems")
        self.orders = LocalMongoCollection("orders")

if not use_real_mongo:
    db = LocalMongoDB()

# Helper: Hash password
def hash_password(pwd):
    return hashlib.sha256(pwd.encode('utf-8')).hexdigest()

# Helper: Format Mongo doc to JSON
def format_doc(doc):
    if not doc:
        return None
    doc_copy = dict(doc)
    if "_id" in doc_copy:
        doc_copy["_id"] = str(doc_copy["_id"])
        doc_copy["id"] = doc_copy["_id"]
    return doc_copy

# ------------------------------------------------------------------------------
# 2. INITIAL SEED DATA (10+ Dishes & Default Admin)
# ------------------------------------------------------------------------------
SAMPLE_DISHES = [
    # --- 1. Fresh Canteen Meals & Fast Food ---
    {
        "_id": "dish-1",
        "name": "Samosa (2 Pcs)",
        "category": "Canteen Food",
        "price": 25,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80",
        "description": "Crispy golden pastry triangles stuffed with spiced potatoes and peas, served with sweet tamarind chutney."
    },
    {
        "_id": "dish-2",
        "name": "Aloo Paratha with Curd",
        "category": "Canteen Food",
        "price": 40,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80",
        "description": "Hot buttered whole wheat flatbread stuffed with spiced mashed potatoes, served with fresh curd & pickle."
    },
    {
        "_id": "dish-3",
        "name": "Veg Grilled Sandwich",
        "category": "Canteen Food",
        "price": 45,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80",
        "description": "Fresh grilled vegetable sandwich loaded with cucumber, tomato, cheese slice, and green mint chutney."
    },
    {
        "_id": "dish-4",
        "name": "Masala Dosa",
        "category": "Canteen Food",
        "price": 50,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=600&auto=format&fit=crop&q=80",
        "description": "Crispy thin rice crepe filled with fragrant potato masala, served with coconut chutney & hot sambar."
    },
    {
        "_id": "dish-5",
        "name": "Veg Hakka Chowmein",
        "category": "Canteen Food",
        "price": 60,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=600&auto=format&fit=crop&q=80",
        "description": "Street-style stir fried noodles with crunchy shredded vegetables, soya sauce, and spicy garlic chili."
    },
    {
        "_id": "dish-6",
        "name": "Paneer Special Thali",
        "category": "Canteen Food",
        "price": 90,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&auto=format&fit=crop&q=80",
        "description": "Complete nutritious lunch meal with paneer butter masala, 2 rotis, steamed rice, dal fry & salad."
    },
    # --- 2. Chocolates & Candies ---
    {
        "_id": "dish-7",
        "name": "Cadbury Dairy Milk Silk (60g)",
        "category": "Chocolates & Candies",
        "price": 80,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=600&auto=format&fit=crop&q=80",
        "description": "Rich, smooth and creamy milk chocolate bar for chocolate lovers."
    },
    {
        "_id": "dish-8",
        "name": "Nestlé KitKat 4-Finger Bar",
        "category": "Chocolates & Candies",
        "price": 30,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1621996346565-e3d5d6281699?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1621996346565-e3d5d6281699?w=600&auto=format&fit=crop&q=80",
        "description": "Crispy wafer fingers covered with delicious milk chocolate. Have a break, have a KitKat!"
    },
    {
        "_id": "dish-9",
        "name": "Snickers Peanut Chocolate Bar",
        "category": "Chocolates & Candies",
        "price": 40,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1582293041079-7814c2f12063?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1582293041079-7814c2f12063?w=600&auto=format&fit=crop&q=80",
        "description": "Loaded with roasted peanuts, nougat, caramel and milk chocolate. Hunger helper!"
    },
    # --- 3. Packaged Snacks & Chips ---
    {
        "_id": "dish-10",
        "name": "Lay's India's Magic Masala",
        "category": "Snacks & Chips",
        "price": 20,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80",
        "description": "Crunchy spicy potato chips bursting with authentic Indian street spices."
    },
    {
        "_id": "dish-11",
        "name": "Kurkure Masala Munch (Pack)",
        "category": "Snacks & Chips",
        "price": 20,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1621447504864-d8686e12698c?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1621447504864-d8686e12698c?w=600&auto=format&fit=crop&q=80",
        "description": "Iconic crunchy corn puffs seasoned with tangy spice blend."
    },
    {
        "_id": "dish-12",
        "name": "Maggi 2-Minute Masala Noodles Pack",
        "category": "Snacks & Chips",
        "price": 15,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=600&auto=format&fit=crop&q=80",
        "description": "Hostelers' all-time favorite instant masala noodles packet for quick hostel cooking."
    },
    # --- 4. Packaged Drinks & Juices ---
    {
        "_id": "dish-13",
        "name": "Cold Coffee with Ice Cream",
        "category": "Drinks & Juices",
        "price": 50,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=600&auto=format&fit=crop&q=80",
        "description": "Rich blended creamy iced coffee topped with chocolate syrup and a vanilla scoop."
    },
    {
        "_id": "dish-14",
        "name": "Frooti Mango Drink (Tetra Pack)",
        "category": "Drinks & Juices",
        "price": 20,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1546173159-315724a31696?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1546173159-315724a31696?w=600&auto=format&fit=crop&q=80",
        "description": "Sweet refreshing mango pulp drink served chilled."
    },
    {
        "_id": "dish-15",
        "name": "Red Bull Energy Drink (Can)",
        "category": "Drinks & Juices",
        "price": 115,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80",
        "description": "Vitalizes body and mind during exam nights and intense college study sessions."
    },
    # --- 5. Stationery & Study Supplies ---
    {
        "_id": "dish-16",
        "name": "Classmate Long Spiral Register (300 Pages)",
        "category": "Stationery",
        "price": 65,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=600&auto=format&fit=crop&q=80",
        "description": "High-quality bright white smooth ruled pages, ideal for semester notes and lecture notes."
    },
    {
        "_id": "dish-17",
        "name": "Reynolds Blue & Black Gel Pen Set (2 Pcs)",
        "category": "Stationery",
        "price": 20,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1585336261026-7f576d338f0d?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1585336261026-7f576d338f0d?w=600&auto=format&fit=crop&q=80",
        "description": "Smooth waterproof fast-drying gel ink pens with comfortable grip for exam writing."
    },
    {
        "_id": "dish-18",
        "name": "College Practical Assignment File Folder",
        "category": "Stationery",
        "price": 25,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop&q=80",
        "description": "Durable clip folder for submitting BCA lab practical files and university assignments."
    },
    # --- 6. Hostel & Daily Essentials ---
    {
        "_id": "dish-19",
        "name": "Dettol Pocket Hand Sanitizer (50ml)",
        "category": "Hostel Essentials",
        "price": 25,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=600&auto=format&fit=crop&q=80",
        "description": "Instant 99.9% germ protection rinse-free sanitizer with refreshing fragrance."
    },
    {
        "_id": "dish-20",
        "name": "Soft Pocket Facial Tissues (Pack of 3)",
        "category": "Hostel Essentials",
        "price": 20,
        "type": "veg",
        "available": True,
        "isAvailable": True,
        "image": "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=600&auto=format&fit=crop&q=80",
        "imageUrl": "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=600&auto=format&fit=crop&q=80",
        "description": "Extra soft 2-ply facial paper tissues for college bags and quick cleanups."
    }
]

def init_db_defaults():
    # 1. Create Default Admin if none exists
    admin_user = db.users.find_one({"email": "admin@canteen.edu"})
    if not admin_user:
        db.users.insert_one({
            "_id": "admin-1",
            "uid": "admin-1",
            "name": "Canteen Admin",
            "email": "admin@canteen.edu",
            "password": hash_password("admin123"),
            "rollNo": "ADMIN-01",
            "department": "Canteen Management",
            "phone": "9876543210",
            "role": "admin",
            "createdAt": datetime.now().isoformat()
        })
        print("[OK] Default Admin created: admin@canteen.edu / admin123")

    # 2. Seed Initial Dishes if foodItems is empty
    if db.foodItems.count_documents({}) == 0:
        for dish in SAMPLE_DISHES:
            dish_copy = dict(dish)
            dish_copy["createdAt"] = datetime.now().isoformat()
            db.foodItems.insert_one(dish_copy)
        print(f"[OK] Seeded {len(SAMPLE_DISHES)} default canteen food items into MongoDB database.")

init_db_defaults()

# ------------------------------------------------------------------------------
# 3. AUTHENTICATION REST API
# ------------------------------------------------------------------------------

@app.route("/api/auth/register", methods=["POST"])
def register():
    data = request.json or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    rollNo = data.get("rollNo", "").strip()
    department = data.get("department", "BCA").strip()
    phone = data.get("phone", "").strip()

    if not name or not email or not password:
        return jsonify({"success": False, "message": "Name, email, and password are required."}), 400

    existing = db.users.find_one({"email": email})
    if existing:
        return jsonify({"success": False, "message": "This email is already registered. Please log in."}), 400

    # Check if user is applying for staff permission
    apply_for_staff = data.get("applyForStaff", False) or (data.get("role") == "pending_admin")
    role = "pending_admin" if apply_for_staff else "student"
    staff_designation = data.get("staffDesignation", "Counter / Kitchen Staff").strip() if apply_for_staff else None

    user_id = str(uuid.uuid4())
    user_doc = {
        "_id": user_id,
        "uid": user_id,
        "name": name,
        "email": email,
        "password": hash_password(password),
        "rollNo": rollNo,
        "department": department,
        "phone": phone,
        "role": role,
        "staffDesignation": staff_designation,
        "createdAt": datetime.now().isoformat()
    }
    db.users.insert_one(user_doc)

    user_safe = format_doc(user_doc)
    del user_safe["password"]

    msg = "Staff Admin request submitted! It is pending approval by Super Admin Deepak." if apply_for_staff else "Account created successfully!"
    return jsonify({"success": True, "message": msg, "user": user_safe}), 201


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.json or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"success": False, "message": "Email and password are required."}), 400

    user = db.users.find_one({"email": email})
    if not user or user.get("password") != hash_password(password):
        return jsonify({"success": False, "message": "Invalid email or password."}), 401

    user_safe = format_doc(user)
    if "password" in user_safe:
        del user_safe["password"]

    return jsonify({"success": True, "message": "Login successful!", "user": user_safe}), 200


# ------------------------------------------------------------------------------
# 4. FOOD MENU (CRUD) REST API
# ------------------------------------------------------------------------------

@app.route("/api/menu", methods=["GET"])
def get_menu():
    items = [format_doc(item) for item in db.foodItems.find({})]
    return jsonify({"success": True, "items": items}), 200


@app.route("/api/menu", methods=["POST"])
def add_food_item():
    data = request.json or {}
    name = data.get("name", "").strip()
    price = data.get("price", 0)
    category = data.get("category", "Breakfast")
    item_type = data.get("type", "veg")
    image = data.get("image") or data.get("imageUrl") or "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=80"
    description = data.get("description", "")
    available = data.get("available", True)

    if not name or price <= 0:
        return jsonify({"success": False, "message": "Valid name and price are required."}), 400

    item_doc = {
        "_id": str(uuid.uuid4()),
        "name": name,
        "price": float(price),
        "category": category,
        "type": item_type,
        "image": image,
        "imageUrl": image,
        "description": description,
        "available": bool(available),
        "isAvailable": bool(available),
        "createdAt": datetime.now().isoformat()
    }
    db.foodItems.insert_one(item_doc)
    return jsonify({"success": True, "message": "Food item added successfully!", "item": format_doc(item_doc)}), 201


@app.route("/api/menu/<item_id>", methods=["PUT"])
def update_food_item(item_id):
    data = request.json or {}
    update_data = {}
    
    for key in ["name", "price", "category", "type", "description", "available", "isAvailable"]:
        if key in data:
            update_data[key] = data[key]
    
    if "image" in data or "imageUrl" in data:
        img = data.get("image") or data.get("imageUrl")
        update_data["image"] = img
        update_data["imageUrl"] = img

    if "available" in data:
        update_data["isAvailable"] = data["available"]
    if "isAvailable" in data:
        update_data["available"] = data["isAvailable"]

    update_data["updatedAt"] = datetime.now().isoformat()

    db.foodItems.update_one({"_id": item_id}, {"$set": update_data})
    return jsonify({"success": True, "message": "Food item updated successfully!"}), 200


@app.route("/api/menu/<item_id>", methods=["DELETE"])
def delete_food_item(item_id):
    db.foodItems.delete_one({"_id": item_id})
    return jsonify({"success": True, "message": "Food item deleted successfully!"}), 200


@app.route("/api/menu/seed", methods=["POST"])
def seed_menu():
    for dish in SAMPLE_DISHES:
        existing = db.foodItems.find_one({"name": dish["name"]})
        if not existing:
            dish_copy = dict(dish)
            dish_copy["_id"] = str(uuid.uuid4())
            dish_copy["createdAt"] = datetime.now().isoformat()
            db.foodItems.insert_one(dish_copy)
    return jsonify({"success": True, "message": "10+ Sample dishes seeded successfully into MongoDB!"}), 200


# ------------------------------------------------------------------------------
# 5. ORDERS REST API
# ------------------------------------------------------------------------------

@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.json or {}
    items = data.get("items", [])
    user_id = data.get("userId")

    if not items or not user_id:
        return jsonify({"success": False, "message": "Items and user ID are required."}), 400

    order_id = data.get("orderId") or f"ORD-{int(datetime.now().timestamp() * 1000) % 900000 + 100000}"
    subtotal = float(data.get("subtotal", 0))
    packaging_fee = float(data.get("packagingFee", 5))
    total_amount = float(data.get("totalAmount", subtotal + packaging_fee))

    order_doc = {
        "_id": str(uuid.uuid4()),
        "orderId": order_id,
        "userId": user_id,
        "customerName": data.get("customerName") or data.get("studentName", "Student"),
        "customerEmail": data.get("customerEmail") or data.get("studentEmail", ""),
        "studentName": data.get("customerName") or data.get("studentName", "Student"),
        "studentRoll": data.get("studentRoll", "N/A"),
        "studentDept": data.get("studentDept", "N/A"),
        "studentPhone": data.get("studentPhone", "N/A"),
        "studentEmail": data.get("customerEmail") or data.get("studentEmail", ""),
        "items": items,
        "subtotal": subtotal,
        "packagingFee": packaging_fee,
        "totalAmount": total_amount,
        "pickupSlot": data.get("pickupSlot", "Immediate"),
        "specialNotes": data.get("specialNotes", ""),
        "paymentMethod": data.get("paymentMethod", "Pay on Pickup Counter"),
        "paymentStatus": "Pending",
        "status": "Pending", # Pending -> Preparing -> Ready -> Completed -> Cancelled
        "createdAt": datetime.now().isoformat(),
        "updatedAt": datetime.now().isoformat()
    }

    db.orders.insert_one(order_doc)
    return jsonify({"success": True, "message": "Pre-order placed successfully!", "order": format_doc(order_doc)}), 201


@app.route("/api/orders", methods=["GET"])
def get_orders():
    user_id = request.args.get("userId")
    query = {"userId": user_id} if user_id else {}
    orders = [format_doc(order) for order in db.orders.find(query)]
    
    # Sort by createdAt descending
    orders.sort(key=lambda x: x.get("createdAt", ""), reverse=True)
    return jsonify({"success": True, "orders": orders}), 200


@app.route("/api/orders/<order_id>/status", methods=["PUT"])
def update_order_status(order_id):
    data = request.json or {}
    new_status = data.get("status")
    
    if not new_status:
        return jsonify({"success": False, "message": "Status is required."}), 400

    # Search by _id or orderId
    order = db.orders.find_one({"_id": order_id}) or db.orders.find_one({"orderId": order_id})
    if not order:
        return jsonify({"success": False, "message": "Order not found."}), 404

    target_id = order["_id"]
    db.orders.update_one({"_id": target_id}, {"$set": {"status": new_status, "updatedAt": datetime.now().isoformat()}})
    return jsonify({"success": True, "message": f"Order status updated to {new_status}!"}), 200


# ------------------------------------------------------------------------------
# 6. PROFILE & ADMIN STATS REST API
# ------------------------------------------------------------------------------

@app.route("/api/profile/<user_id>", methods=["GET"])
def get_profile(user_id):
    user = db.users.find_one({"_id": user_id}) or db.users.find_one({"uid": user_id})
    if not user:
        return jsonify({"success": False, "message": "User not found."}), 404
    
    user_safe = format_doc(user)
    if "password" in user_safe:
        del user_safe["password"]
    return jsonify({"success": True, "user": user_safe}), 200


@app.route("/api/profile/<user_id>", methods=["PUT"])
def update_profile(user_id):
    data = request.json or {}
    update_data = {}
    for key in ["name", "rollNo", "department", "phone"]:
        if key in data:
            update_data[key] = data[key]
    
    update_data["updatedAt"] = datetime.now().isoformat()
    db.users.update_one({"_id": user_id}, {"$set": update_data})
    return jsonify({"success": True, "message": "Profile updated successfully!"}), 200


@app.route("/api/admin/stats", methods=["GET"])
def get_admin_stats():
    all_orders = db.orders.find({})
    total_orders = len(all_orders)
    pending_count = sum(1 for o in all_orders if o.get("status") == "Pending")
    active_prep_count = sum(1 for o in all_orders if o.get("status") in ["Preparing", "Ready"])
    completed_count = sum(1 for o in all_orders if o.get("status") == "Completed")
    total_revenue = sum(float(o.get("totalAmount", 0)) for o in all_orders if o.get("status") == "Completed")
    total_items = db.foodItems.count_documents({})

    return jsonify({
        "success": True,
        "stats": {
            "totalOrders": total_orders,
            "pendingOrders": pending_count,
            "activePrep": active_prep_count,
            "completedOrders": completed_count,
            "totalRevenue": total_revenue,
            "totalFoodItems": total_items
        }
    }), 200


@app.route("/api/admin/staff", methods=["GET"])
def get_staff_list():
    all_users = [format_doc(u) for u in db.users.find({})]
    for u in all_users:
        if "password" in u:
            del u["password"]
    
    pending = [u for u in all_users if u.get("role") == "pending_admin"]
    active = [u for u in all_users if u.get("role") in ["admin", "superadmin"]]
    return jsonify({"success": True, "pendingStaff": pending, "activeStaff": active}), 200


@app.route("/api/admin/staff/<user_id>", methods=["PUT"])
def manage_staff(user_id):
    data = request.json or {}
    action = data.get("action", "").lower()
    
    user = db.users.find_one({"_id": user_id}) or db.users.find_one({"uid": user_id})
    if not user:
        return jsonify({"success": False, "message": "User not found."}), 404
    
    target_id = user["_id"]
    if action == "approve":
        db.users.update_one({"_id": target_id}, {"$set": {"role": "admin", "approvedAt": datetime.now().isoformat()}})
        return jsonify({"success": True, "message": f"Successfully approved {user.get('name')} as Canteen Admin!"}), 200
    elif action in ["reject", "revoke"]:
        db.users.update_one({"_id": target_id}, {"$set": {"role": "student", "staffDesignation": None, "revokedAt": datetime.now().isoformat()}})
        return jsonify({"success": True, "message": f"Access updated. {user.get('name')} is now a regular Student."}), 200
    else:
        return jsonify({"success": False, "message": "Invalid action."}), 400


# ------------------------------------------------------------------------------
# 7. STATIC FILES SERVING (HTML, CSS, JS)
# ------------------------------------------------------------------------------

@app.route("/")
def serve_index():
    return send_from_directory(".", "index.html")

@app.route("/<path:path>")
def serve_static(path):
    if os.path.exists(path):
        return send_from_directory(".", path)
    return send_from_directory(".", "index.html")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print("=" * 70)
    print("  [SERVER] Campus Canteen - MongoDB Backend Server Running")
    print(f"  [SERVER] Local Web App URL: http://localhost:{port}/index.html")
    print(f"  [SERVER] Default Admin: admin@canteen.edu / admin123")
    print("=" * 70)
    app.run(host="0.0.0.0", port=port, debug=False)
